package org.ejavaexample.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventPipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventPipeApplication.class, args);
	}

}
