package org.ejavaexample.cartservice.config;

public class SecurityConfig {

}
