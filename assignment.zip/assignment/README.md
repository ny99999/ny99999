# JavaEE_assignment
JavaEE_assignment
组队信息：
20301167-乔芳盛
203011  -王天宇
203011  -史庄毅
